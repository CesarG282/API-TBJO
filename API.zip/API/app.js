const express = require ('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

app.use(bodyParser.json());
const postRoute = require('./routes/post');
app.use('/servicios', postRoute);

app.get('/', (req,res) => {
    res.send('prueba una respuesta del servidor');
}); 

async function connectToDatabase() {
  try {
      await mongoose.connect('mongodb+srv://garcisces4r:28nacional@api.gquinzt.mongodb.net/?retryWrites=true&w=majority', {
          useNewUrlParser: true,
          useUnifiedTopology: true
      });
      console.log('Connected to MongoDB');
      app.listen(10000);
  } catch (error) {
      console.error('Error connecting to MongoDB:', error);
  }
}

connectToDatabase();